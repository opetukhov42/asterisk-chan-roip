#!/usr/bin/env python3
"""
Integrate chan_roip into OpenWrt's telephony-feed asterisk package.

Usage: integrate.py <SDK_DIR> <SRC_DIR>

Performs four idempotent edits to feeds/telephony/net/asterisk/Makefile:
  1. add 'chan-roip' to MODULES_AVAILABLE
  2. add the BuildAsteriskModule declaration
  3. widen the --with-asound condition to also trigger on our module
  4. add a Build/Prepare hook that copies the source into channels/
...and copies chan_roip.c (+ optional sample conf) into the package's files/.
Line endings are normalised to LF so it works when edited on Windows.
"""
import os
import re
import sys

def norm_lf(path):
    with open(path, "rb") as f:
        data = f.read()
    data = data.replace(b"\r\n", b"\n").replace(b"\r", b"\n")
    with open(path, "wb") as f:
        f.write(data)

def main():
    if len(sys.argv) != 3:
        sys.exit("usage: integrate.py <SDK_DIR> <SRC_DIR>")
    sdk, src = sys.argv[1], sys.argv[2]

    pkgdir = os.path.join(sdk, "feeds", "telephony", "net", "asterisk")
    mkfile = os.path.join(pkgdir, "Makefile")
    if not os.path.isfile(mkfile):
        sys.exit(f"!! asterisk Makefile not found at {mkfile}\n"
                 f"   (did './scripts/feeds install' run? is the telephony feed present?)")

    with open(mkfile, "r", encoding="utf-8") as f:
        mk = f.read()

    if "chan-roip" in mk:
        print("   Makefile already integrated; skipping edits.")
    else:
        # 1) MODULES_AVAILABLE: add after the chan-alsa line
        mk, n = re.subn(r"(\n[ \t]*chan-alsa[ \t]*\\\n)",
                        r"\1\tchan-roip \\\n", mk, count=1)
        if n != 1:
            sys.exit("!! could not find 'chan-alsa \\' in MODULES_AVAILABLE")

        # 2) BuildAsteriskModule declaration: after the chan-alsa eval line
        eval_line = ("$(eval $(call BuildAsteriskModule,chan-roip,"
                     "ALSA radio channel,ALSA + serial radio channel driver with PTT/COR.,"
                     "+alsa-lib,roip.conf,chan_roip,,))\n")
        mk, n = re.subn(r"(\$\(eval \$\(call BuildAsteriskModule,chan-alsa,[^\n]*\)\)\n)",
                        r"\1" + eval_line.replace("\\", "\\\\"), mk, count=1)
        if n != 1:
            sys.exit("!! could not find the chan-alsa BuildAsteriskModule line")

        # 3) widen --with-asound to also trigger on chan-roip
        mk, n = re.subn(
            r"\$\(if \$\(CONFIG_PACKAGE_\$\(PKG_NAME\)-chan-alsa\),--with-asound=\"\$\(STAGING_DIR\)/usr\",--without-asound\)",
            "$(if $(or $(CONFIG_PACKAGE_$(PKG_NAME)-chan-alsa),$(CONFIG_PACKAGE_$(PKG_NAME)-chan-roip)),"
            "--with-asound=\"$(STAGING_DIR)/usr\",--without-asound)",
            mk, count=1)
        if n != 1:
            print("   WARN: could not widen --with-asound automatically. "
                  "Ensure ALSA is configured (or also select asterisk-chan-alsa).")

        # 4) Build/Prepare hook: insert before 'define Build/menuselect'
        prepare = (
            "define Build/Prepare\n"
            "\t$(call Build/Prepare/Default)\n"
            "\t$(INSTALL_DIR) $(PKG_BUILD_DIR)/channels\n"
            "\t$(CP) ./files/chan_roip.c $(PKG_BUILD_DIR)/channels/chan_roip.c\n"
            "\t$(INSTALL_DIR) $(PKG_BUILD_DIR)/configs/samples\n"
            "\t$(CP) ./files/roip.conf.sample $(PKG_BUILD_DIR)/configs/samples/roip.conf.sample\n"
            "endef\n\n"
        )
        if "define Build/Prepare" in mk:
            sys.exit("!! package already defines Build/Prepare; manual merge needed.")
        mk, n = re.subn(r"(define Build/menuselect\n)", prepare + r"\1", mk, count=1)
        if n != 1:
            # fallback: append at end of file (make evaluates recipes lazily)
            mk += "\n" + prepare

        with open(mkfile, "w", encoding="utf-8") as f:
            f.write(mk)
        print("   Makefile edited (4 changes applied).")

    # copy source + sample into files/, normalising line endings
    filesdir = os.path.join(pkgdir, "files")
    os.makedirs(filesdir, exist_ok=True)
    for name in ("chan_roip.c", "roip.conf.sample"):
        s = os.path.join(src, name)
        if not os.path.isfile(s):
            if name == "roip.conf.sample":
                print(f"   note: {name} not provided; skipping sample conf.")
                continue
            sys.exit(f"!! required source {s} not found")
        d = os.path.join(filesdir, name)
        with open(s, "rb") as fi, open(d, "wb") as fo:
            fo.write(fi.read())
        norm_lf(d)
        print(f"   copied {name} -> {d}")

    print("   Integration complete.")

if __name__ == "__main__":
    main()
