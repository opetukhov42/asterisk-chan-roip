#!/usr/bin/env bash
#
# Build asterisk-chan-roip for one OpenWrt target.
#
# Required env:
#   TARGET   e.g. "x86/64", "x86/generic", "bcm27xx/bcm2711"
# Optional env:
#   VERSION  OpenWrt release (default 24.10.1)
#   JOBS     parallel jobs (default: nproc)
#   ALSO_BUILD_BASE   if "1", also copy the base asterisk .ipk (for guaranteed sum match)
#
set -euo pipefail

: "${TARGET:?Set TARGET, e.g. TARGET=x86/64}"
VERSION="${VERSION:-24.10.1}"
JOBS="${JOBS:-$(nproc)}"
ALSO_BUILD_BASE="${ALSO_BUILD_BASE:-0}"

SRC=/work/src
OUTBASE=/out
OUTDIR="${OUTBASE}/$(echo "$TARGET" | tr '/' '-')"
BASEURL="https://downloads.openwrt.org/releases/${VERSION}/targets/${TARGET}"

echo "==> Target : ${TARGET}"
echo "==> Release: ${VERSION}"
echo "==> Source : ${BASEURL}"

# --- Locate the SDK tarball by reading the target's directory listing ---
echo "==> Discovering SDK filename..."
INDEX="$(curl -fsSL "${BASEURL}/")"
SDK="$(printf '%s\n' "$INDEX" | grep -oE 'openwrt-sdk-[^"<> ]*\.tar\.(zst|xz)' | sort -u | head -n1 || true)"
if [ -z "$SDK" ]; then
    echo "!! Could not find an SDK for ${TARGET} at ${BASEURL}"
    echo "!! Check that the target/subtarget is spelled correctly and exists for ${VERSION}."
    exit 1
fi
echo "==> SDK: ${SDK}"

cd /home/builder
if [ ! -f "$SDK" ]; then
    echo "==> Downloading SDK..."
    curl -fSL -o "$SDK" "${BASEURL}/${SDK}"
fi

# --- Verify checksum if available (best effort) ---
if curl -fsSL -o sha256sums "${BASEURL}/sha256sums" 2>/dev/null; then
    if grep -q " \*\?${SDK}\$" sha256sums; then
        echo "==> Verifying sha256..."
        grep " \*\?${SDK}\$" sha256sums | sed "s/\*//" | sha256sum -c - || { echo "!! Checksum FAILED"; exit 1; }
    fi
fi

# --- Extract SDK ---
SDKDIR=/home/builder/sdk
rm -rf "$SDKDIR"; mkdir -p "$SDKDIR"
echo "==> Extracting SDK..."
case "$SDK" in
    *.tar.zst) tar --zstd -xf "$SDK" -C "$SDKDIR" --strip-components=1 ;;
    *.tar.xz)  tar -xJf   "$SDK" -C "$SDKDIR" --strip-components=1 ;;
    *) echo "!! Unknown SDK archive type: $SDK"; exit 1 ;;
esac
cd "$SDKDIR"

# --- Feeds ---
echo "==> Setting up feeds..."
cp feeds.conf.default feeds.conf
./scripts/feeds update -a
./scripts/feeds install -a

# --- Integrate the module into the asterisk package ---
echo "==> Integrating chan_roip..."
python3 /work/integrate.py "$SDKDIR" "$SRC"

# --- Configure: enable our package (and its deps) as a module ---
echo "==> Configuring..."
{
    echo "CONFIG_PACKAGE_asterisk=m"
    echo "CONFIG_PACKAGE_asterisk-chan-roip=m"
    echo "CONFIG_PACKAGE_alsa-lib=m"
} >> .config
make defconfig

# --- Build ---
echo "==> Building (this pulls & builds Asterisk 20.8.1 + the module; be patient)..."
if ! make "package/feeds/telephony/asterisk/compile" -j"${JOBS}" V=s 2>&1 | tee /home/builder/build.log; then
    echo "!! Build failed. Last 40 lines:"; tail -n 40 /home/builder/build.log
    exit 1
fi

# --- Collect results ---
mkdir -p "$OUTDIR"
echo "==> Collecting .ipk files into ${OUTDIR}"
find bin/ -name 'asterisk-chan-roip_*.ipk' -exec cp -v {} "$OUTDIR/" \;
if [ "$ALSO_BUILD_BASE" = "1" ]; then
    find bin/ -name 'asterisk_*.ipk' -exec cp -v {} "$OUTDIR/" \; || true
fi

if ls "$OUTDIR"/asterisk-chan-roip_*.ipk >/dev/null 2>&1; then
    echo "==> DONE. Files in ${OUTDIR}:"
    ls -la "$OUTDIR"
else
    echo "!! No .ipk produced. See /home/builder/build.log"
    exit 1
fi
